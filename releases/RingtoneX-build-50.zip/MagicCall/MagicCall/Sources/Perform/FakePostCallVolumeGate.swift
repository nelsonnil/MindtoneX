import Foundation

/// Fake Ringtone: when hardware volume buttons may toggle playback (Advanced).
enum FakePostCallVolumeGate {
    static func shouldTogglePlayOnVolume(
        volumeButtonTrigger: Bool,
        isArmed: Bool,
        performed: Bool
    ) -> Bool {
        volumeButtonTrigger && isArmed && !performed
    }
}

/// Fake Ringtone: long-press on stage opens Share only after the spectator’s call ends.
enum FakePostCallShareGate {
    static func shouldOpenShareOnLongPress(
        performanceMode: Prefs.PerformanceMode,
        phase: AppModel.Phase,
        performed: Bool,
        isArmed: Bool
    ) -> Bool {
        performanceMode == .fakeRingtone && phase == .stage && performed && isArmed
    }
}

#if DEBUG
enum FakePostCallVolumeGateSelfTest {
    static func run() {
        assert(FakePostCallVolumeGate.shouldTogglePlayOnVolume(
            volumeButtonTrigger: true, isArmed: true, performed: false))
        assert(!FakePostCallVolumeGate.shouldTogglePlayOnVolume(
            volumeButtonTrigger: true, isArmed: true, performed: true))
        assert(FakePostCallShareGate.shouldOpenShareOnLongPress(
            performanceMode: .fakeRingtone, phase: .stage, performed: true, isArmed: true))
        assert(!FakePostCallShareGate.shouldOpenShareOnLongPress(
            performanceMode: .fakeRingtone, phase: .stage, performed: false, isArmed: true))
    }
}
#endif
